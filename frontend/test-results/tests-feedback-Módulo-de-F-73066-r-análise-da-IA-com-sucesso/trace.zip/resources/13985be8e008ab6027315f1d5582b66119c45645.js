(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/ThemeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeProvider",
    ()=>ThemeProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-themes/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
function ThemeProvider({ children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$themes$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ThemeProvider.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = ThemeProvider;
var _c;
__turbopack_context__.k.register(_c, "ThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/locales/en.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "en",
    ()=>en
]);
const en = {
    header: {
        overview: "Store Overview",
        orderTracking: "Live Order Tracking",
        reviews: "Reviews & AI Analysis",
        realTime: "System updated in real-time"
    },
    menu: {
        overview: "Overview",
        management: "Order Management",
        reviews: "Customer Reviews",
        logout: "Logout"
    },
    cards: {
        revenue: "Total Revenue",
        profit: "Estimated Profit",
        orders: "Total Orders",
        margin: "Profit Margin"
    },
    charts: {
        sales: {
            title: "Sales Trend",
            subtitle: "Financial Performance",
            tooltip: "Daily Revenue",
            footer: "Gross Revenue",
            badge: "Exact Calculation"
        },
        topProducts: {
            title: "Top Sellers",
            subtitle: "Menu Metrics",
            tooltip: "Product Insights",
            sold: "units sold",
            footer: "Order volume over period"
        },
        bairros: {
            title: "Orders by Region",
            subtitle: "Geographic Distribution",
            tooltip: "Logistics Analysis",
            total: "Total Orders",
            badge: "High Demand Zone",
            footer: "Logistics Heatmap"
        },
        horarios: {
            title: "Operational Flow",
            subtitle: "Peak Time Analytics",
            tooltip: "Time Window",
            orders: "Orders",
            high: "High Demand Period",
            low: "Low Demand Period",
            footer: "Workload Monitoring",
            badge: "Live Sync"
        },
        pagamentos: {
            title: "Revenue by Method",
            subtitle: "Financial Channels",
            total: "Total Revenue",
            tooltip: "Detailed Distribution",
            share: "{percent}% of total volume",
            footer: "Audited data via iFood API",
            methods: {
                credit: "Credit Card",
                debit: "Debit Card",
                cash: "Cash",
                pix: "Pix"
            }
        }
    },
    kanban: {
        orderId: "Order ID",
        totalValue: "Total Value",
        tickets: "tickets",
        dropHere: "Drop orders here",
        limit: "Only the latest 10 tickets are visible",
        columns: {
            pending: "New Orders",
            preparing: "In Kitchen",
            completed: "Dispatched"
        },
        toasts: {
            moved: "Order moved to",
            syncError: "Failed to sync kitchen orders.",
            updateError: "Failed to update server. Reverting action."
        },
        status: {
            live: "Kitchen Link: Active",
            offline: "Kitchen Link: Offline",
            workstation: "Preparing Workstation"
        }
    },
    simulate: {
        button: "Simulate Order",
        processing: "Processing...",
        success: "Transaction simulated successfully!",
        errorApi: "Failed to communicate with the API.",
        errorUnknown: "Unknown error while simulating transaction."
    },
    feedbacks: {
        title: "Customer Voice",
        subtitle: "Real feedback extracted from the database and analyzed by the AI Assistant.",
        newSimulation: "New Simulation",
        empty: "The database is empty. Use the button above to simulate.",
        positive: "Positive",
        negative: "Negative",
        aiAssistant: "AI Assistant",
        analyzing: "Analyzing database...",
        insightsTitle: "Insights generated based on recent feedback:",
        context: "Context",
        recommendation: "Recommendation",
        acknowledge: "Acknowledge"
    },
    settings: {
        title: "Dashboard Settings",
        description: "Customize chart visibility and sizing.",
        orderTitle: "Organization",
        orderSub: "Drag to reorder",
        visibility: "Visibility",
        size: "Size",
        close: "Close"
    },
    metaModal: {
        title: "Set Annual Target",
        label: "Target Value ($)",
        placeholder: "e.g.: 500000",
        save: "Save Target",
        cancel: "Cancel",
        success: "Target updated successfully!"
    },
    common: {
        export: "Export Report",
        today: "Today",
        last7Days: "7 Days",
        last30Days: "30 Days"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/locales/pt.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pt",
    ()=>pt
]);
const pt = {
    header: {
        overview: "Visão Geral da Loja",
        orderTracking: "Acompanhamento de Pedidos",
        reviews: "Avaliações e Análise de IA",
        realTime: "Sistema atualizado em tempo real"
    },
    menu: {
        overview: "Visão Geral",
        management: "Gestão de Pedidos",
        reviews: "Avaliações de Clientes",
        logout: "Sair"
    },
    cards: {
        revenue: "Faturamento Bruto",
        profit: "Lucro Estimado",
        orders: "Total de Pedidos",
        margin: "Margem de Lucro"
    },
    charts: {
        sales: {
            title: "Evolução de Vendas",
            subtitle: "Performance Financeira",
            tooltip: "Receita Diária",
            footer: "Faturamento Bruto",
            badge: "Cálculo Exato"
        },
        topProducts: {
            title: "Campeões de Vendas",
            subtitle: "Métricas de Menu",
            tooltip: "Dados do Campeão",
            sold: "unidades vendidas",
            footer: "Volume de pedidos no período"
        },
        bairros: {
            title: "Pedidos por Região",
            subtitle: "Distribuição Geográfica",
            tooltip: "Análise de Logística",
            total: "Pedidos Totais",
            badge: "Zona de Alta Demanda",
            footer: "Mapeamento de Calor Logístico"
        },
        horarios: {
            title: "Fluxo Operacional",
            subtitle: "Inteligência de Pico",
            tooltip: "Janela de Tempo",
            orders: "Pedidos",
            high: "Momento de Alta Demanda",
            low: "Momento de Baixa Demanda",
            footer: "Monitoramento de Carga de Trabalho",
            badge: "Sincronizado"
        },
        pagamentos: {
            title: "Faturamento por Método",
            subtitle: "Canais Financeiros",
            total: "Receita Total",
            tooltip: "Distribuição Detalhada",
            share: "{percent}% do volume total",
            footer: "Dados auditados via API iFood",
            methods: {
                credit: "Cartão de Crédito",
                debit: "Cartão de Débito",
                cash: "Dinheiro",
                pix: "Pix"
            }
        }
    },
    kanban: {
        orderId: "ID do Pedido",
        totalValue: "Valor Total",
        tickets: "pedidos",
        dropHere: "Solte os pedidos aqui",
        limit: "Apenas os últimos 10 pedidos são visíveis",
        columns: {
            pending: "Novos Pedidos",
            preparing: "Na Cozinha",
            completed: "Despachados"
        },
        toasts: {
            moved: "Pedido movido para",
            syncError: "Falha ao sincronizar pedidos da cozinha.",
            updateError: "Erro ao atualizar servidor. Revertendo ação."
        },
        status: {
            live: "Link Cozinha: Ativo",
            offline: "Link Cozinha: Offline",
            workstation: "Preparando Estação de Trabalho"
        }
    },
    simulate: {
        button: "Simular Pedido",
        processing: "Processando...",
        success: "Transação simulada com sucesso!",
        errorApi: "Falha na comunicação com a API.",
        errorUnknown: "Erro desconhecido ao simular transação."
    },
    feedbacks: {
        title: "Voz do Cliente",
        subtitle: "Feedbacks reais extraídos do banco de dados e analisados pelo Assistente de IA.",
        newSimulation: "Nova Simulação",
        empty: "O banco de dados está vazio. Use o botão acima para simular.",
        positive: "Positivo",
        negative: "Negativo",
        aiAssistant: "Assistente de IA",
        analyzing: "Analisando banco de dados...",
        insightsTitle: "Insights gerados com base em feedbacks recentes:",
        context: "Contexto",
        recommendation: "Recomendação",
        acknowledge: "Ciente"
    },
    settings: {
        title: "Configurações do Dashboard",
        description: "Personalize a visibilidade e o tamanho dos seus gráficos.",
        orderTitle: "Organização",
        orderSub: "Arraste para reordenar",
        visibility: "Visibilidade",
        size: "Tamanho",
        close: "Fechar"
    },
    metaModal: {
        title: "Definir Meta Anual",
        label: "Valor da Meta (R$)",
        placeholder: "Ex: 500000",
        save: "Salvar Meta",
        cancel: "Cancelar",
        success: "Meta atualizada com sucesso!"
    },
    common: {
        export: "Exportar Relatório",
        today: "Hoje",
        last7Days: "7 Dias",
        last30Days: "30 Dias"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/contexts/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/locales/en.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$locales$2f$pt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/locales/pt.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const translations = {
    en: __TURBOPACK__imported__module__$5b$project$5d2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"],
    pt: __TURBOPACK__imported__module__$5b$project$5d2f$locales$2f$pt$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pt"]
};
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    lang: "en",
    t: __TURBOPACK__imported__module__$5b$project$5d2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"],
    toggleLanguage: ()=>{},
    formatCurrency: (v)=>v.toString()
});
function LanguageProvider({ children }) {
    _s();
    const [lang, setLang] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "LanguageProvider.useState": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                const savedLang = localStorage.getItem("app_lang");
                return savedLang || "en";
            }
            //TURBOPACK unreachable
            ;
        }
    }["LanguageProvider.useState"]);
    const toggleLanguage = ()=>{
        const nextLang = lang === "en" ? "pt" : "en";
        setLang(nextLang);
        localStorage.setItem("app_lang", nextLang);
    };
    // ✅ Lógica de Conversão e Formatação Real
    const formatCurrency = (value)=>{
        const exchangeRate = 5.0; // 1 USD = 5 BRL
        if (lang === "en") {
            const converted = value / exchangeRate;
            return new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD"
            }).format(converted);
        }
        return new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL"
        }).format(value);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            lang,
            t: translations[lang],
            toggleLanguage,
            formatCurrency
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/contexts/LanguageContext.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "TqGfnPKoLzN1WcRy8xG1cccygMg=");
_c = LanguageProvider;
const useLanguage = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
};
_s1(useLanguage, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_0wlx0g6._.js.map