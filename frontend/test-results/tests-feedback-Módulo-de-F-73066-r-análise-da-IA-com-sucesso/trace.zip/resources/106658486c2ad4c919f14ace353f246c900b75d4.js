(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0zf1xwb._.js","static/chunks/_0pe08cs._.js","static/chunks/node_modules_next_0.62.0t._.js","static/chunks/node_modules_recharts_es6_util_0~sf8vv._.js","static/chunks/node_modules_recharts_es6_component_09l6q5y._.js","static/chunks/node_modules_recharts_es6_state_0.iwwvd._.js","static/chunks/node_modules_recharts_es6_cartesian_0~fc_fq._.js","static/chunks/node_modules_recharts_es6_063o-mi._.js","static/chunks/node_modules_@dnd-kit_core_dist_core_esm_0avyu8m.js","static/chunks/node_modules_html2canvas-pro_dist_html2canvas-pro_esm_0uiuj~x.js","static/chunks/node_modules_pako_dist_pako_esm_mjs_09ei-9a._.js","static/chunks/node_modules_jspdf_dist_jspdf_es_min_02b56x3.js","static/chunks/node_modules_0qm42me._.js"],
    source: "dynamic"
});
